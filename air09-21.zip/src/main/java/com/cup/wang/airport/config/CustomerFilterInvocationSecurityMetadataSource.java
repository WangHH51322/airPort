package com.cup.wang.airport.config;

import com.cup.wang.airport.model.Role;
import com.cup.wang.airport.model.Menu;
import com.cup.wang.airport.service.MenuService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;

import java.util.Collection;
import java.util.List;

/**
 * @author Qing
 * @version 1.0
 * @date 2020/8/19 20:04
 */
@Component
public class CustomerFilterInvocationSecurityMetadataSource implements FilterInvocationSecurityMetadataSource {

    @Autowired
    MenuService menuService;
    AntPathMatcher antPathMatcher = new AntPathMatcher();//比对用的工具

    @Override
    public Collection<ConfigAttribute> getAttributes(Object o) throws IllegalArgumentException { //当前请求需要的角色
        String requestUrl = ((FilterInvocation) o).getRequestUrl(); //获取当前请求的地址
        java.util.List<Menu> menus = menuService.getAllMenusWithRole(); //获取当前角色对应的menu里面的url
        for (Menu menu : menus) {
            if (antPathMatcher.match(menu.getUrl(),requestUrl)){ // 对比当前请求的地址和menu里面的url
                List<Role> roles = menu.getRoles();
                String[] str = new String[roles.size()];
                for (int i = 0; i < roles.size(); i++) {
                    str[i] = roles.get(i).getName();
                }
                return SecurityConfig.createList(str); // 返回url对的上的menu里面的角role
            }
        }
        return SecurityConfig.createList("ROLE_LOGIN"); //如果没有匹配上,登陆之后都可以访问
    }

    @Override
    public Collection<ConfigAttribute> getAllConfigAttributes() {
        return null;
    }

    @Override
    public boolean supports(Class<?> aClass) {
        return true;
    }
}

